# Safe_in_forest > safe_in_forest
https://universe.roboflow.com/datamolbase/safe_in_forest

Provided by a Roboflow user
License: CC BY 4.0

